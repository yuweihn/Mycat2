create table `TABLE_NAMES` (
	`Tables_in_testdb` varchar (292),
	`Table_type` varchar (256)
);

insert into `TABLE_NAMES` (`Tables_in_testdb`, `Table_type`) values('travelrecord','BASE TABLE');
insert into `TABLE_NAMES` (`Tables_in_testdb`, `Table_type`) values('address','BASE TABLE');
