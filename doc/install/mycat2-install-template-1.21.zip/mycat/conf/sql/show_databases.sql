create table `SCHEMATA` (
	`Database` varchar (256)
);
insert into `SCHEMATA` (`Database`) values('TESTDB');
insert into `SCHEMATA` (`Database`) values('TESTDB2');
