create table `TABLE_NAMES` (
	`Tables_in_testdb2` varchar (292),
	`Table_type` varchar (256)
);